package com.flexmonth.arwa;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText reps, seconds, rest;
    TextView stage, timer, status;
    VideoView video;
    Button pause;
    android.content.SharedPreferences prefs;
    Handler handler = new Handler(Looper.getMainLooper());
    boolean running=false, paused=false, resting=false;
    int remaining=30, stageNo=1;
    String[] stages={"التهيئة","الإحماء","الحركة الجانبية","الوقفة الواسعة","التمدد الواسع","التمدد الأرضي","تمدد الحوض","الانحناء الأمامي","الحركة الديناميكية","الختام"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        reps=findViewById(R.id.reps); seconds=findViewById(R.id.seconds); rest=findViewById(R.id.rest);
        stage=findViewById(R.id.stage); timer=findViewById(R.id.timer); status=findViewById(R.id.status);
        video=findViewById(R.id.video); pause=findViewById(R.id.pause);
        prefs=getSharedPreferences("flex",0);
        reps.setText(""+prefs.getInt("reps",10)); seconds.setText(""+prefs.getInt("seconds",30)); rest.setText(""+prefs.getInt("rest",15));
        String path="android.resource://"+getPackageName()+"/"+getResources().getIdentifier("workout","raw",getPackageName());
        try { video.setVideoURI(Uri.parse(path)); } catch(Exception ignored){}
        // Asset playback fallback
        try { video.setVideoPath("file:///android_asset/workout.mp4"); } catch(Exception ignored){}

        findViewById(R.id.save).setOnClickListener(v -> saveSettings());
        findViewById(R.id.start).setOnClickListener(v -> startSession());
        pause.setOnClickListener(v -> { paused=!paused; pause.setText(paused?"استئناف":"إيقاف مؤقت"); status.setText(paused?"متوقف مؤقتًا":"كمّلي!"); });
        timer.setText(format(getSeconds()));
    }
    int num(EditText e,int d){try{return Math.max(0,Integer.parseInt(e.getText().toString()));}catch(Exception x){return d;}}
    int getSeconds(){return prefs.getInt("seconds",30);}
    void saveSettings(){
        prefs.edit().putInt("reps",num(reps,10)).putInt("seconds",num(seconds,30)).putInt("rest",num(rest,15)).apply();
        remaining=getSeconds(); timer.setText(format(remaining)); Toast.makeText(this,"تم حفظ الإعدادات ✓",Toast.LENGTH_SHORT).show();
    }
    void startSession(){
        saveSettings(); stageNo=1; resting=false; paused=false; running=true; pause.setText("إيقاف مؤقت");
        status.setText("العداد: "+prefs.getInt("reps",10)+" عدة"); startStage();
    }
    void startStage(){
        if(stageNo>stages.length){running=false; stage.setText("اكتملت الجلسة 🎉"); timer.setText("✓"); status.setText("أحسنتِ!"); return;}
        stage.setText("المرحلة "+stageNo+" · "+stages[stageNo-1]);
        resting=false; remaining=getSeconds(); status.setText("العدات: "+prefs.getInt("reps",10)+" · المدة المحددة: "+remaining+" ثانية");
        tick();
    }
    void tick(){
        handler.postDelayed(()->{
            if(!running)return;
            if(paused){tick();return;}
            remaining--; timer.setText(format(remaining));
            if(remaining<=0){ startRest(); } else tick();
        },1000);
        timer.setText(format(remaining));
    }
    void startRest(){
        resting=true; remaining=prefs.getInt("rest",15); stage.setText("استراحة"); status.setText("خدي نفسًا واستعدي للمرحلة التالية");
        handler.postDelayed(()->{
            if(!running)return;
            if(paused){startRest();return;}
            remaining--; timer.setText(format(remaining));
            if(remaining<=0){stageNo++;startStage();}else startRest();
        },1000);
    }
    String format(int s){return String.format(Locale.US,"%02d:%02d",s/60,s%60);}
}
