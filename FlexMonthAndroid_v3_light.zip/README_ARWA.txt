Flex Month v3
- Android native project.
- Video embedded in res/raw/workout.mp4.
- User can set reps, exercise duration (seconds), and rest duration.
- Settings are saved locally.
- Session has independent stages, countdown, rest intervals, pause/resume, and automatic advance.
- 28-day planning can be layered on top in the next build; this v3 focuses on the customizable session engine requested.
Build: open the folder in Android Studio, wait for Gradle sync, then Build > Build APK(s).
